#!/bin/sh
# ============================================================
# K2P 节点测速 / 切换 (v2 - 稳定版)
# ------------------------------------------------------------
# 关键改进:
#   1. 不重启 Xray 测速 (避免崩溃)
#   2. 用真实 IP 节点 (避开 fake-IP 问题)
#   3. 切节点用精确的 awk 替换 (不用 sed 多行匹配)
#
# 用法:
#   pick_node.sh auto     # 自动测速选最优
#   pick_node.sh scan     # 只扫描不切换
#   pick_node.sh list     # 列出节点
#   pick_node.sh set n15  # 手动切换
#   pick_node.sh show     # 当前状态
# ============================================================

export PATH=/sbin:/bin:/usr/sbin:/usr/bin:$PATH

XRAY_BIN="/opt/bin/xray"
XRAY_DIR="/etc/storage/xray_k2p"
CFG="$XRAY_DIR/config.json"
RUNTIME_CFG="/tmp/xray_cfg.json"
LOG="/tmp/pick_node.log"

log() { echo "$(date '+%m-%d %H:%M:%S') $1" >> "$LOG"; echo "$1"; }

# ---------- 解析节点列表 ----------
# 输出: tag address  (每行一个)
get_node_list() {
    awk '
        /"tag"[ ]*:[ ]*"n[0-9]+"/ {
            line = $0
            sub(/.*"tag"[ ]*:[ ]*"/, "", line)
            sub(/".*/, "", line)
            tag = line
            want = 1
            next
        }
        want && /"address"[ ]*:/ {
            line = $0
            sub(/.*"address"[ ]*:[ ]*"/, "", line)
            sub(/".*/, "", line)
            print tag, line
            want = 0
        }
    ' "$CFG" 2>/dev/null
}

# ---------- 当前节点 ----------
current_node() {
    # ⚠️ 必须从 "outboundTag": "nX" 整行提取
    # grep -o "n[0-9]*" 会匹配到 outboundTag 里的字母 n
    grep '"outboundTag"' "$CFG" 2>/dev/null | tail -1 | sed 's/.*"outboundTag": "//; s/".*//'
}

# ---------- 停止 Xray (可靠方式) ----------
stop_xray() {
    _pid=$(pidof xray 2>/dev/null)
    if [ -n "$_pid" ]; then
        kill $_pid 2>/dev/null
        sleep 2
        # 强制
        _pid=$(pidof xray 2>/dev/null)
        [ -n "$_pid" ] && kill -9 $_pid 2>/dev/null
        sleep 1
    fi
    [ -z "$(pidof xray 2>/dev/null)" ]
}

# ---------- 启动 Xray ----------
start_xray() {
    ulimit -n 4096 2>/dev/null
    "$XRAY_BIN" -c "$RUNTIME_CFG" > /tmp/xray_run.log 2>&1 &
    sleep 5
    [ -n "$(pidof xray 2>/dev/null)" ]
}

# ---------- 用 awk 精确替换节点 (多行安全) ----------
replace_node() {
    _new="$1"
    awk -v new="$_new" '
        /"outboundTag"[ ]*:[ ]*"n[0-9]+"/ {
            sub(/"n[0-9]+"/, "\"" new "\"")
        }
        { print }
    ' "$CFG" > /tmp/cfg_new.json 2>/dev/null

    # 验证
    if awk -v new="$_new" '
        /"outboundTag"[ ]*:[ ]*"n[0-9]+"/ {
            if ($0 ~ "\"" new "\"") found = 1
        }
        END { exit (found ? 0 : 1) }
    ' /tmp/cfg_new.json 2>/dev/null; then
        mv -f /tmp/cfg_new.json "$CFG"
        cp -f "$CFG" "$RUNTIME_CFG"
        return 0
    fi
    rm -f /tmp/cfg_new.json
    return 1
}

# ---------- 测试节点 (直接连, 不通过 Xray) ----------
# 原理: 直接 curl 节点的 IP:port, 看能否建立 TLS 连接
# 这样不需要重启 Xray
test_node_direct() {
    _addr="$1"
    _port="${2:-443}"

    # 只测纯 IPv4 (域名受 fake-IP 影响, 测了也不准)
    _is_ip=$(echo "$_addr" | awk -F. 'NF==4 && $1~/^[0-9]+$/ && $2~/^[0-9]+$/ && $3~/^[0-9]+$/ && $4~/^[0-9]+$/ {print "yes"}')
    [ "$_is_ip" != "yes" ] && { echo "999"; return; }

    # 测 TLS 握手延迟
    _t=$(/usr/sbin/curl -s -o /dev/null -m 6 -w "%{time_total}" \
         --connect-timeout 5 -k "https://${_addr}:${_port}" 2>/dev/null)
    _code=$?

    if [ "$_code" -eq 0 ] || [ "$_code" -eq 60 ] || [ "$_code" -eq 35 ]; then
        # 0=成功, 60=证书问题(说明TCP通了), 35=SSL错误(也说明TCP通了)
        echo "${_t:-999}"
    else
        echo "999"
    fi
}

# ---------- 切换并验证 ----------
switch_and_verify() {
    _tag="$1"
    log "  切换到 $_tag ..."

    replace_node "$_tag" || { log "  ❌ 替换失败"; return 1; }

    stop_xray
    start_xray || { log "  ❌ Xray 启动失败"; return 1; }

    # 验证出网
    _ip=$(/usr/sbin/curl -s -m 12 -x socks5h://127.0.0.1:10808 https://api.ipify.org 2>/dev/null)
    if [ -n "$_ip" ]; then
        log "  ✅ 成功! 出口 IP: $_ip"
        return 0
    fi
    log "  ❌ 无法出网"
    return 1
}

case "$1" in
# ============================================================
auto|scan)
    log "===== 节点测速 ====="
    CUR=$(current_node)
    log "当前节点: ${CUR:-未知}"

    # 获取节点列表
    get_node_list > /tmp/nodes.txt
    TOTAL=$(wc -l < /tmp/nodes.txt)

    # 只测真实 IP 节点 (用 awk 严格判断 IPv4)
    awk '$2 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ {print $1, $2}' /tmp/nodes.txt > /tmp/nodes_ip.txt
    NIP=$(wc -l < /tmp/nodes_ip.txt)
    log "节点总数: $TOTAL, 可直测(真实IP): $NIP"
    echo ""

    if [ "$NIP" -eq 0 ]; then
        log "无真实 IP 节点"
        exit 1
    fi

    # 逐个测延迟
    BEST=""
    BEST_T="999"
    i=0
    while read tag addr; do
        i=$((i+1))
        T=$(test_node_direct "$addr")
        printf "  [%2d/%2d] %-5s %-20s 延迟: %s\n" "$i" "$NIP" "$tag" "$addr" "$T"
    done < /tmp/nodes_ip.txt > /tmp/scan_result.txt 2>&1

    cat /tmp/scan_result.txt

    # 排序找最优 (字段: $4=tag, $7=延迟)
    awk '
        /延迟:/ {
            tag = $4
            t = $7
            if (t == "999" || t == "") next
            if (best == "" || t+0 < best+0) { best = t; besttag = tag }
        }
        END { if (besttag) print besttag, best }
    ' /tmp/scan_result.txt > /tmp/best.txt

    BEST=$(awk '{print $1}' /tmp/best.txt)
    BEST_T=$(awk '{print $2}' /tmp/best.txt)

    if [ "$1" = "scan" ]; then
        log "最快节点: ${BEST:-无} (${BEST_T}s) [仅扫描, 未切换]"
        rm -f /tmp/nodes.txt /tmp/nodes_ip.txt /tmp/scan_result.txt /tmp/best.txt
        exit 0
    fi

    if [ -n "$BEST" ]; then
        log "最优节点: $BEST (延迟 ${BEST_T}s)"
        if switch_and_verify "$BEST"; then
            log "===== 完成 ====="
        else
            log "⚠️ 切换后验证失败, 恢复原节点"
            [ -n "$CUR" ] && switch_and_verify "$CUR"
        fi
    else
        log "❌ 未找到可用节点"
        [ -n "$CUR" ] && echo "保持原节点: $CUR"
    fi
    rm -f /tmp/nodes.txt /tmp/nodes_ip.txt /tmp/scan_result.txt /tmp/best.txt /tmp/cfg_new.json
    ;;

# ============================================================
set)
    [ -z "$2" ] && { echo "用法: $0 set <节点名>"; exit 1; }
    switch_and_verify "$2"
    ;;

# ============================================================
list)
    echo "节点列表:"
    get_node_list | while read tag addr; do
        # 用 awk 判断是否纯 IPv4
        IS_IP=$(echo "$addr" | awk -F. 'NF==4 && $1~/^[0-9]+$/ && $2~/^[0-9]+$/ && $3~/^[0-9]+$/ && $4~/^[0-9]+$/ {print "yes"}')
        if [ "$IS_IP" = "yes" ]; then
            M="[真实IP]"
        else
            M="[域名]"
        fi
        printf "  %-5s %-45s %s\n" "$tag" "$addr" "$M"
    done
    ;;

# ============================================================
show)
    echo "当前节点: $(current_node)"
    echo "Xray:      $(pidof xray >/dev/null 2>&1 && echo "运行中 (PID $(pidof xray))" || echo 未运行)"
    echo -n "出口 IP:   "
    /usr/sbin/curl -s -m 10 -x socks5h://127.0.0.1:10808 https://api.ipify.org 2>/dev/null || echo "失败"
    echo ""
    ;;

*)
    echo "K2P 节点测速/切换 (v2)"
    echo
    echo "用法: $0 {auto|scan|list|set <节点>|show}"
    echo
    echo "  auto      - 测速并切换到最优节点"
    echo "  scan      - 只测速不切换"
    echo "  list      - 列出所有节点"
    echo "  set n15   - 手动切换"
    echo "  show      - 当前状态"
    ;;
esac
