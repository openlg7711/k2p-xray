# K2P Xray 代理 (PHICOMM K2P / MT7621 / 老毛子 Padavan)

备用路由器 K2P 的科学上网方案。K2P 作为灾备路由器:
小主机(ESXi+OpenWrt)故障时, 直接接光猫拨号顶替。

## ⚠️ 重要: 必须用本仓库的 xray.gz

**不要用 GitHub 官方的 Xray!**

MT7621 (MIPS 1004Kc) 没有硬件浮点单元 (FPU)。
官方版编译时用了硬浮点指令 -> 在这台设备上 Segmentation fault。

本仓库是 softfloat 编译版, 实测可正常运行。
解压后 md5 校验值: 32c5912bb26576f963f9b952afa99cab

## 文件说明

| 文件 | 说明 |
|---|---|
| xray.gz | Xray 1.8.24 softfloat 版 (解压后 30MB) |
| config.json.gz | Xray 配置 (34 个节点, vless-reality) |
| china_ip.txt.gz | 中国 IP 段 (7456 条, 国内直连分流) |
| xray_k2p_start.sh.gz | 启动脚本 |
| watchdog.sh.gz | 看门狗 (保国内网) |
| failover.sh.gz | 灾备自动切换 |
| switch_mode.sh.gz | 手动模式切换 |

## 为什么全用 .gz

K2P 的 flash 持久分区只有 5.7MB (放不下 30MB 的 Xray),
且系统只有 gunzip 没有 unzip, 所以所有文件都用 gzip 压缩。
Xray 运行时下载解压到内存盘 /opt/bin/xray, 不占 flash。

## K2P 硬件约束

- CPU: MediaTek MT7621 (MIPS 1004Kc, 2核, 无 FPU)
- RAM: 126MB
- Flash: 16MB (持久分区只有 5.7MB)
- 系统: hiboy Padavan, kernel 3.4.113, BusyBox 1.29.3
- 无 USB, 无 unzip, 无 python

## 已排除的方案 (别再试)

| 方案 | 结果 |
|---|---|
| 固件自带 v2ray5 | OOM (内存不足) |
| 固件自带 clash-meta | OOM (RSS 42MB) |
| 固件自带 sing-box | Segfault |
| 固件自带 clashpre | 能跑但不支持 vless-reality |
| GitHub 官方 Xray | Segfault (硬浮点) |

结论: 只能用 softfloat 版 Xray。

## 换机场 / 换节点

1. 把新订阅转成 Xray 配置
2. 替换本仓库的 config.json.gz
3. 重启 K2P (会自动拉取新配置)

## 保底机制

设计目标: 科学上网不行时, 国内网站必须能上

1. 中国 IP 集合直连 (国内流量根本不进 Xray)
2. 看门狗每 2 分钟检查, Xray 挂了立即清空代理规则
3. 启动失败自动回滚, 绝不留半残规则
4. 连百度都打不开时, 强制清空所有代理规则
