#!/bin/sh
# ============================================================
# K2P 工作模式切换脚本
# ------------------------------------------------------------
# 用途: 小主机(OpenWrt)挂了时, 让 K2P 顶上做主路由
#
# 用法:
#   switch_mode.sh primary    # 切换为主路由 (PPPoE 拨号)
#   switch_mode.sh backup     # 切换回备用模式 (DHCP 二级路由)
#   switch_mode.sh status     # 查看当前模式
#
# 特点:
#   - LAN 网段保持 192.168.3.1 不变 (不与小主机冲突)
#   - PPPoE 账号用 nvram 里已存的
#   - 切换后自动重启网络服务
#   - 科学上网自动跟随
# ============================================================

export PATH=/sbin:/bin:/usr/sbin:/usr/bin:$PATH

LOG="/tmp/switch_mode.log"
log() { echo "$(date '+%m-%d %H:%M:%S') $1" | tee -a "$LOG"; logger -t "k2p_mode" "$1"; }

MODE="$1"

show_status() {
    echo "========== 当前状态 =========="
    echo "WAN 协议:  $(nvram get wan0_proto)"
    echo "WAN 接口:  $(nvram get wan0_ifname)"
    echo "PPPoE账号: $(nvram get wan0_pppoe_username)"
    echo "LAN IP:    $(nvram get lan_ipaddr)"
    echo
    echo "实际连接:"
    ip route show default 2>/dev/null | sed 's/^/  /'
    echo
    echo "WAN 口 IP:"
    for i in $(ip -o addr show 2>/dev/null | awk '$2 ~ /^(eth3|ppp)/ {print $2}'); do
        ip addr show "$i" 2>/dev/null | grep "inet " | sed "s/^/  $i: /"
    done
    echo
    echo "Xray:      $(pgrep xray >/dev/null && echo '运行中' || echo '未运行')"
    echo "透明代理:  $(iptables -t mangle -L XRAY_TPROXY -n >/dev/null 2>&1 && echo '已配置' || echo '未配置')"
}

case "$MODE" in
# ============================================================
primary)
    log "===== 切换到主路由模式 (PPPoE) ====="

    # --- 1. 保存当前配置 (可回滚) ---
    nvram get wan0_proto > /tmp/mode_backup_proto 2>/dev/null
    log "已保存当前模式: $(cat /tmp/mode_backup_proto)"

    # --- 2. 检查 PPPoE 账号 ---
    PUSER=$(nvram get wan0_pppoe_username 2>/dev/null)
    PPASS=$(nvram get wan0_pppoe_passwd 2>/dev/null)
    if [ -z "$PUSER" ] || [ -z "$PPASS" ]; then
        log "错误: PPPoE 账号或密码为空, 无法拨号"
        log "  账号: ${PUSER:-空}"
        exit 1
    fi
    log "PPPoE 账号: $PUSER"

    # --- 3. 设置为 PPPoE ---
    nvram set wan0_proto=pppoe
    nvram set wan0_pppoe_mtu=1492
    nvram set wan0_pppoe_mru=1492
    # DNS 用公共的 (防运营商劫持)
    nvram set wan0_dns="223.5.5.5 119.29.29.29"
    nvram commit
    log "nvram 已更新为 PPPoE"

    # --- 4. MSS 钳制 (PPPoE 必需) ---
    for chain in FORWARD OUTPUT; do
        iptables -t mangle -D $chain -p tcp --tcp-flags SYN,RST SYN \
                 -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null
        iptables -t mangle -A $chain -p tcp --tcp-flags SYN,RST SYN \
                 -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null
    done
    log "MSS 钳制已应用"

    # --- 5. 重启网络 ---
    log "重启网络服务 (约 30 秒)..."
    restart_wan 2>/dev/null || {
        # 备用方案: 直接重启网络
        killall pppd 2>/dev/null
        sleep 2
        /sbin/ifup wan 2>/dev/null || service restart_wan 2>/dev/null
    }

    sleep 25
    show_status

    # --- 6. 等 PPPoE 拨号成功 ---
    tries=0
    while [ $tries -lt 12 ]; do
        if ip route show default 2>/dev/null | grep -q "ppp"; then
            log "✅ PPPoE 拨号成功!"
            break
        fi
        tries=$((tries+1))
        sleep 5
    done

    if [ $tries -ge 12 ]; then
        log "⚠️ PPPoE 未在 60 秒内拨号成功, 请检查:"
        log "  1. 光猫是否真的桥接"
        log "  2. 网线是否插在 K2P 的 WAN 口"
        log "  3. PPPoE 账号密码是否正确"
    fi

    # --- 7. 启动 Xray ---
    sleep 5
    /etc/storage/xray_k2p/start.sh &
    log "已触发 Xray 启动"
    log "===== 切换完成 ====="
    ;;

# ============================================================
backup)
    log "===== 切换回备用模式 (DHCP 二级路由) ====="

    nvram set wan0_proto=dhcp
    nvram set wan0_dns=""
    nvram commit
    log "nvram 已改回 DHCP"

    killall pppd 2>/dev/null
    sleep 2
    restart_wan 2>/dev/null || service restart_wan 2>/dev/null

    sleep 20
    show_status

    # 重启 Xray (网络变了)
    sleep 5
    /etc/storage/xray_k2p/start.sh &
    log "===== 切换完成 ====="
    ;;

# ============================================================
status)
    show_status
    ;;

*)
    echo "K2P 工作模式切换"
    echo
    echo "用法: $0 {primary|backup|status}"
    echo
    echo "  primary  - 切换为主路由 (PPPoE 拨号, 替代小主机)"
    echo "  backup   - 切换回备用模式 (DHCP 二级路由)"
    echo "  status   - 查看当前状态"
    exit 1
    ;;
esac
