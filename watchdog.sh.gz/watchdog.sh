#!/bin/sh
# ============================================================
# K2P Xray 看门狗
# ------------------------------------------------------------
# 职责:
#   1. Xray 挂了 -> 立即清空代理规则 (恢复直连) -> 尝试重启
#   2. 确保国内网站任何时候都能上
#   3. 代理规则异常时自动修复
# ============================================================

export PATH=/sbin:/bin:/usr/sbin:/usr/bin:/opt/bin:$PATH

XRAY_BIN="/opt/bin/xray"
XRAY_DIR="/etc/storage/xray_k2p"
LOG="/tmp/xray_k2p.log"
CHECK_INTERVAL=120

log() { echo "$(date '+%m-%d %H:%M:%S') [看门狗] $1" >> "$LOG"; logger -t "xray_wd" "$1"; }

# 获取 LAN 网段
get_lan_net() {
    LAN_IP=$(ip addr show br0 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1)
    [ -z "$LAN_IP" ] && LAN_IP=$(nvram get lan_ipaddr 2>/dev/null)
    [ -z "$LAN_IP" ] && LAN_IP="192.168.3.1"
    echo "$LAN_IP" | cut -d. -f1-3 | awk '{print $1".0/24"}'
}

# 清空代理规则 (恢复直连)
clear_rules() {
    LAN_NET=$(get_lan_net)
    iptables -t mangle -D PREROUTING -p tcp -s "$LAN_NET" -j XRAY_TPROXY 2>/dev/null
    iptables -t mangle -F XRAY_TPROXY 2>/dev/null
    iptables -t mangle -X XRAY_TPROXY 2>/dev/null
    ip rule del fwmark 1 table 100 2>/dev/null
}

# 重建代理规则
rebuild_rules() {
    LAN_NET=$(get_lan_net)
    iptables -t mangle -N XRAY_TPROXY 2>/dev/null
    iptables -t mangle -F XRAY_TPROXY 2>/dev/null

    iptables -t mangle -A XRAY_TPROXY -d 198.18.0.0/16 -j RETURN
    for net in 0.0.0.0/8 10.0.0.0/8 127.0.0.0/8 169.254.0.0/16 172.16.0.0/12 \
               192.168.0.0/16 224.0.0.0/4 240.0.0.0/4 100.64.0.0/10; do
        iptables -t mangle -A XRAY_TPROXY -d $net -j RETURN
    done
    iptables -t mangle -A XRAY_TPROXY -m set --match-set china dst -j RETURN
    iptables -t mangle -A XRAY_TPROXY -p tcp -j TPROXY --on-port 10810 --tproxy-mark 1

    iptables -t mangle -D PREROUTING -p tcp -s "$LAN_NET" -j XRAY_TPROXY 2>/dev/null
    iptables -t mangle -A PREROUTING -p tcp -s "$LAN_NET" ! -i lo -j XRAY_TPROXY

    ip rule add fwmark 1 table 100 2>/dev/null
    ip route add local 0.0.0.0/0 dev lo table 100 2>/dev/null
}

# 应急: 确保国内网站能上 (核心保底)
ensure_cn_ok() {
    # 检查 basic 直连是否正常
    if ! /usr/sbin/curl -s -o /dev/null -m 8 http://www.baidu.com 2>/dev/null; then
        log "国内访问异常! 强制清除所有代理规则"
        clear_rules
        # 清 DNS 缓存
        killall -HUP dnsmasq 2>/dev/null
        sleep 3
        if /usr/sbin/curl -s -o /dev/null -m 8 http://www.baidu.com 2>/dev/null; then
            log "国内访问已恢复"
        else
            log "国内访问仍异常 (可能是上游网络问题)"
        fi
    fi
}

log "看门狗启动 (间隔 ${CHECK_INTERVAL}s)"

fails=0

while true; do
    sleep $CHECK_INTERVAL

    # --- 检查 1: Xray 进程 ---
    if ! pgrep xray >/dev/null 2>&1; then
        fails=$((fails+1))
        log "检测到 Xray 已停止 (第 $fails 次)"

        # 立即清规则, 保证不断网
        clear_rules
        log "已清除代理规则, 恢复正常上网"

        # 尝试重启 (最多连续 3 次, 之后降频)
        if [ $fails -le 3 ]; then
            sleep 3
            ulimit -n 4096 2>/dev/null
            if [ -f /tmp/xray_cfg.json ]; then
                "$XRAY_BIN" -c /tmp/xray_cfg.json > /tmp/xray_run.log 2>&1 &
            else
                "$XRAY_DIR/start.sh" &
            fi
            sleep 6
            if pgrep xray >/dev/null 2>&1; then
                log "重启成功"
                rebuild_rules
                fails=0
            else
                log "重启失败, 等待下次"
            fi
        else
            log "连续失败 $fails 次, 降频处理 (等待 10 分钟)"
            sleep 600
        fi
        continue
    fi

    # --- 检查 2: 规则是否存在 ---
    if ! iptables -t mangle -L XRAY_TPROXY -n >/dev/null 2>&1; then
        log "检测到代理规则丢失, 重建中"
        rebuild_rules
        log "规则已重建"
    fi

    # --- 检查 3: 国内访问保底 ---
    ensure_cn_ok

    fails=0
done
