#!/bin/sh
# ============================================================
# K2P 灾备自动切换守护进程
# ------------------------------------------------------------
# 场景: ESXi 小主机挂了, 你把光猫网线插到 K2P 的 WAN 口,
#       这个脚本会自动检测并切换到 PPPoE 拨号模式。
#
# 判断逻辑 (每 60 秒检查一次):
#
#   1. WAN 口没插网线          -> 什么都不做
#   2. WAN 口插着, 且能拿到 DHCP  -> 上级路由还活着, 保持二级路由
#   3. WAN 口插着, 5分钟拿不到 IP
#      且网关不可达             -> 判定为"直连光猫", 自动拨 PPPoE
#
# 切换后:
#   - 启动 PPPoE 拨号
#   - 加 MSS 钳制
#   - 启动 Xray 科学上网
# ============================================================

export PATH=/sbin:/bin:/usr/sbin:/usr/bin:$PATH

LOG="/tmp/k2p_failover.log"
STATE_FILE="/tmp/k2p_failover_state"
CHECK_INTERVAL=60
FAIL_THRESHOLD=5          # 连续 5 次(5分钟)拿不到IP才切换

log() { echo "$(date '+%m-%d %H:%M:%S') [灾备] $1" >> "$LOG"; logger -t "k2p_failover" "$1"; }

# ---------- 读取状态 ----------
get_mode() {
    nvram get wan0_proto 2>/dev/null
}

# WAN 物理口名 (自动检测, 不写死)
get_wan_dev() {
    _d=$(nvram get wan_ifname 2>/dev/null)
    [ -z "$_d" ] && _d="eth3"
    echo "$_d"
}

# WAN 逻辑接口名 (DHCP 模式的 vlan 接口, 如 eth3.2)
get_wan_logical() {
    _d=$(get_wan_dev)
    # 先找默认路由用的接口
    _r=$(ip route show default 2>/dev/null | awk '/default/ {print $5; exit}')
    if [ -n "$_r" ]; then
        echo "$_r"
        return
    fi
    # 退而求其次: 找 $_d 的 vlan 子接口
    for i in $(ip -o link show 2>/dev/null | awk -F': ' '{print $2}' | grep "^${_d}\."); do
        echo "$i"
        return
    done
    echo "$_d"
}

# WAN 口是否插着网线
wan_cable_ok() {
    _d=$(get_wan_dev)
    c=$(cat /sys/class/net/$_d/carrier 2>/dev/null)
    [ "$c" = "1" ]
}

# WAN 是否拿到 IPv4 地址
wan_has_ip() {
    _w=$(get_wan_logical)
    ip addr show "$_w" 2>/dev/null | grep -q "inet " && return 0
    ip addr show ppp0 2>/dev/null | grep -q "inet " && return 0
    # 兜底: 扫所有可能的接口
    ip -o addr show 2>/dev/null | grep -qE " (eth[0-9]+\.?[0-9]*|ppp[0-9]+) .*inet " && return 0
    return 1
}

# 默认网关是否可达
gateway_reachable() {
    gw=$(ip route show default 2>/dev/null | awk '/default/ {print $3; exit}')
    [ -z "$gw" ] && return 1
    ping -c 2 -W 3 "$gw" > /dev/null 2>&1
}

# 公网是否可达 (最终判据)
internet_ok() {
    ping -c 2 -W 4 223.5.5.5 > /dev/null 2>&1
}

# ---------- 切到 PPPoE ----------
switch_to_pppoe() {
    log "===== 自动切换到 PPPoE 主路由模式 ====="

    PUSER=$(nvram get wan0_pppoe_username 2>/dev/null)
    if [ -z "$PUSER" ]; then
        log "错误: 无 PPPoE 账号, 无法切换"
        return 1
    fi
    log "PPPoE 账号: $PUSER"

    nvram set wan0_proto=pppoe
    nvram set wan0_pppoe_mtu=1492
    nvram set wan0_pppoe_mru=1492
    nvram set wan0_dns="223.5.5.5 119.29.29.29"
    nvram commit

    # MSS 钳制
    for chain in FORWARD OUTPUT; do
        iptables -t mangle -D $chain -p tcp --tcp-flags SYN,RST SYN \
                 -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null
        iptables -t mangle -A $chain -p tcp --tcp-flags SYN,RST SYN \
                 -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null
    done
    log "MSS 钳制已应用"

    # DNS 固定
    cat > /etc/resolv.conf << EOF
nameserver 223.5.5.5
nameserver 119.29.29.29
EOF
    killall -HUP dnsmasq 2>/dev/null

    # 拨号
    sleep 2
    restart_wan 2>/dev/null
    log "已触发 PPPoE 拨号, 等待 40 秒..."

    # 等拨号成功
    i=0
    while [ $i -lt 8 ]; do
        sleep 5
        if ip addr show ppp0 2>/dev/null | grep -q "inet "; then
            IP=$(ip addr show ppp0 2>/dev/null | grep "inet " | awk '{print $2}')
            log "✅ PPPoE 拨号成功! 公网 IP: $IP"
            echo "pppoe" > "$STATE_FILE"

            # 启动科学上网
            sleep 5
            [ -x /etc/storage/xray_k2p/start.sh ] && /etc/storage/xray_k2p/start.sh &
            return 0
        fi
        i=$((i+1))
    done

    log "⚠️ PPPoE 拨号超时 (40秒), 请检查账号/光猫设置"
    return 1
}

# ---------- 切回 DHCP ----------
switch_to_dhcp() {
    log "===== 检测到上级路由恢复, 切回 DHCP 二级路由 ====="

    killall pppd 2>/dev/null
    sleep 2
    nvram set wan0_proto=dhcp
    nvram set wan0_dns=""
    nvram commit
    restart_wan 2>/dev/null

    sleep 15
    if wan_has_ip; then
        IP=$(ip addr show eth3.2 2>/dev/null | grep "inet " | awk '{print $2}')
        log "✅ 已切回 DHCP, WAN IP: $IP"
        echo "dhcp" > "$STATE_FILE"
        sleep 5
        [ -x /etc/storage/xray_k2p/start.sh ] && /etc/storage/xray_k2p/start.sh &
        return 0
    fi
    log "⚠️ 切回 DHCP 后未拿到 IP"
    return 1
}

# ============================================================
# 主循环
# ============================================================
log "灾备守护启动 (检查间隔 ${CHECK_INTERVAL}s, 阈值 ${FAIL_THRESHOLD} 次)"

fail_count=0
[ -f "$STATE_FILE" ] || echo "$(get_mode)" > "$STATE_FILE"

while true; do
    sleep $CHECK_INTERVAL

    CUR_MODE=$(get_mode)
    CABEL=$(wan_cable_ok && echo yes || echo no)

    # --- 情况1: 网线没插 ---
    if [ "$CABEL" = "no" ]; then
        [ $fail_count -gt 0 ] && log "WAN 网线已拔出, 重置计数"
        fail_count=0
        continue
    fi

    # --- 情况2: 当前是 PPPoE 模式 ---
    if [ "$CUR_MODE" = "pppoe" ]; then
        if ip addr show ppp0 2>/dev/null | grep -q "inet " && internet_ok; then
            fail_count=0
            continue
        fi

        # PPPoE 掉了, 重拨
        fail_count=$((fail_count+1))
        log "PPPoE 连接异常 (第 $fail_count 次)"

        if [ $fail_count -ge 3 ]; then
            log "重拨 PPPoE"
            restart_wan 2>/dev/null
            sleep 25
            fail_count=0
        fi
        continue
    fi

    # --- 情况3: 当前是 DHCP 模式 ---
    if wan_has_ip && gateway_reachable; then
        # 上级活着, 一切正常
        [ $fail_count -gt 0 ] && log "上级路由已恢复, 重置计数"
        fail_count=0
        continue
    fi

    # 拿不到 IP 或网关不通
    fail_count=$((fail_count+1))
    log "WAN 异常: 无IP或网关不通 (第 $fail_count/$FAIL_THRESHOLD 次)"

    if [ $fail_count -ge $FAIL_THRESHOLD ]; then
        # 二次确认: 真的连不上吗?
        if internet_ok; then
            log "公网其实可达, 不切换"
            fail_count=0
            continue
        fi

        log "判定: 上级路由已失效, 自动切换为 PPPoE 直连"
        if switch_to_pppoe; then
            fail_count=0
        else
            log "切换失败, 60 秒后重试"
            fail_count=$((FAIL_THRESHOLD-1))
        fi
    fi
done
