#!/bin/sh
# ============================================================
# K2P Xray 启动脚本 (老毛子 Padavan)
# ------------------------------------------------------------
# 配置从 GitHub 云端拉取, 换机场只需改 GitHub 上的文件
#
# 特性:
#   1. 自动检测 LAN 网段 (换环境不用改)
#   2. 从 GitHub 拉取 xray.gz + config.json + china_ip.txt
#   3. 多镜像 fallback (jsdelivr / ghproxy / raw)
#   4. 保底: 任何失败都回滚规则, 保证国内网站可上
#   5. 只拦国外流量: 国内 IP 永远直连
# ============================================================

export PATH=/sbin:/bin:/usr/sbin:/usr/bin:/opt/bin:$PATH

XRAY_BIN="/opt/bin/xray"
XRAY_DIR="/etc/storage/xray_k2p"
LOG="/tmp/xray_k2p.log"
XRAY_MD5="32c5912bb26576f963f9b952afa99cab"

# ===== GitHub 仓库配置 =====
# 格式: 用户名/仓库名
GH_REPO="__REPO__"
GH_BRANCH="main"

# 下载镜像 (按顺序尝试)
# 说明: jsdelivr 有 20MB 限制, ghproxy 较稳, raw 可能被墙
GH_MIRRORS="
https://cdn.jsdelivr.net/gh/${GH_REPO}@${GH_BRANCH}
https://ghproxy.net/https://raw.githubusercontent.com/${GH_REPO}/${GH_BRANCH}
https://raw.githubusercontent.com/${GH_REPO}/${GH_BRANCH}
"

log() { echo "$(date '+%m-%d %H:%M:%S') $1" >> "$LOG"; logger -t "xray_k2p" "$1"; }

# ------------------------------------------------------------
# 保底核心: 清空代理规则, 恢复正常上网
# ------------------------------------------------------------
rollback() {
    log "回滚: 清除透明代理规则"
    iptables -t mangle -D PREROUTING -p tcp -j XRAY_TPROXY 2>/dev/null
    iptables -t mangle -D PREROUTING -p tcp -s "$LAN_NET" -j XRAY_TPROXY 2>/dev/null
    iptables -t mangle -F XRAY_TPROXY 2>/dev/null
    iptables -t mangle -X XRAY_TPROXY 2>/dev/null
    ip rule del fwmark 1 table 100 2>/dev/null
    log "已回滚, 国内网站可正常访问"
}

# ------------------------------------------------------------
# 从镜像下载文件: dl <文件名> <输出路径>
# 自动尝试所有镜像和 gz 变体
# ------------------------------------------------------------
dl() {
    _name="$1"; _out="$2"
    for _base in $GH_MIRRORS; do
        # 先试 .gz (jsdelivr 对大文件更好)
        wget -q -O "$_out" --timeout=180 "${_base}/${_name}.gz" 2>/dev/null
        if [ -s "$_out" ] && gzip -t "$_out" 2>/dev/null; then
            gunzip -c "$_out" > "${_out}.tmp" 2>/dev/null
            if [ -s "${_out}.tmp" ]; then
                mv -f "${_out}.tmp" "$_out"
                log "  下载成功: ${_name} (来自 ${_base%%/*}//...)"
                return 0
            fi
        fi

        # 再试原始文件
        wget -q -O "$_out" --timeout=180 "${_base}/${_name}" 2>/dev/null
        if [ -s "$_out" ]; then
            log "  下载成功: ${_name}"
            return 0
        fi
    done
    rm -f "${_out}.tmp"
    return 1
}

log "===== 开始启动 ====="

# ============================================================
# 1. 自动检测 LAN 网段
# ============================================================
LAN_IP=$(ip addr show br0 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1)
[ -z "$LAN_IP" ] && LAN_IP=$(nvram get lan_ipaddr 2>/dev/null)
[ -z "$LAN_IP" ] && LAN_IP="192.168.3.1"
LAN_NET=$(echo "$LAN_IP" | cut -d. -f1-3).0/24
log "LAN: $LAN_IP  网段: $LAN_NET"

# ============================================================
# 2. 内核参数 (防 OOM)
# ============================================================
echo 1 > /proc/sys/vm/overcommit_memory 2>/dev/null
echo 100 > /proc/sys/vm/overcommit_ratio 2>/dev/null

# ============================================================
# 2.5 PPPoE 适配 (光猫桥接 + 拨号场景必需)
# ============================================================
# 判断当前 WAN 是不是 PPPoE
WAN_IFACE=$(ip route show default 2>/dev/null | awk '/default/ {print $5; exit}')
IS_PPPOE=0
case "$WAN_IFACE" in
    ppp*|pppoe*) IS_PPPOE=1 ;;
esac
[ "$(nvram get wan0_proto 2>/dev/null)" = "pppoe" ] && IS_PPPOE=1

# --- MSS 钳制: PPPoE MTU=1492, 但 LAN 设备以为 1500 ---
# 不加会导致: 能 ping 通、小网页能开, 但大流量卡死
for chain in FORWARD OUTPUT; do
    iptables -t mangle -D $chain -p tcp --tcp-flags SYN,RST SYN \
             -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null
done
iptables -t mangle -A FORWARD -p tcp --tcp-flags SYN,RST SYN \
         -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null
log "MSS 钳制已应用 (clamp-mss-to-pmtu)"

if [ "$IS_PPPOE" = "1" ]; then
    log "检测到 PPPoE (WAN: $WAN_IFACE)"

    # --- 固定 DNS: PPPoE 拨号后固件会覆盖 resolv.conf ---
    # 用公共 DNS, 防止运营商劫持/污染导致国外域名解析异常
    case "$(grep -c '223.5.5.5' /etc/resolv.conf 2>/dev/null)" in
        0)
            cat > /etc/resolv.conf << EOF
nameserver 223.5.5.5
nameserver 119.29.29.29
nameserver 223.6.6.6
EOF
            killall -HUP dnsmasq 2>/dev/null
            log "DNS 已固定为公共 DNS (防运营商劫持)"
            ;;
        *)
            log "DNS 已是公共 DNS, 跳过"
            ;;
    esac

    # --- LAN MTU 调整 (可选, 降低分片) ---
    if [ -n "$(nvram get wan0_pppoe_mtu 2>/dev/null)" ]; then
        PMTU=$(nvram get wan0_pppoe_mtu 2>/dev/null)
        log "PPPoE MTU: $PMTU"
    fi
else
    log "非 PPPoE 模式 (WAN: ${WAN_IFACE:-未知}), 跳过 PPPoE 适配"
fi

# ============================================================
# 3. 内核模块
# ============================================================
for m in xt_TPROXY xt_socket ip_set ip_set_hash_net xt_TCPMSS; do
    modprobe $m 2>/dev/null
done

# ============================================================
# 4. 从 GitHub 拉取配置 (每次开机都拉, 保证用最新)
# ============================================================
mkdir -p "$XRAY_DIR"

if [ "$GH_REPO" != "__REPO__" ]; then
    log "从 GitHub 拉取配置: $GH_REPO"
    for f in config.json china_ip.txt; do
        if dl "$f" "/tmp/${f}.new"; then
            # 校验非空且合理
            if [ "$f" = "config.json" ]; then
                if grep -q "outbounds" "/tmp/${f}.new" 2>/dev/null; then
                    cp -f "/tmp/${f}.new" "$XRAY_DIR/$f"
                    cp -f "/tmp/${f}.new" "/tmp/$f"
                    log "  已更新 $f"
                else
                    log "  $f 格式校验失败, 保留旧版"
                fi
            else
                cp -f "/tmp/${f}.new" "$XRAY_DIR/$f"
                log "  已更新 $f"
            fi
        else
            log "  $f 下载失败, 使用本地缓存"
        fi
    done
else
    log "未配置 GitHub 仓库, 使用本地文件"
fi

# ============================================================
# 5. 获取 Xray 二进制
# ============================================================
verify_bin() {
    [ -x "$1" ] || return 1
    cur=$(md5sum "$1" 2>/dev/null | awk '{print $1}')
    [ "$cur" = "$XRAY_MD5" ]
}

if verify_bin "$XRAY_BIN"; then
    log "Xray 已存在且校验通过"
else
    log "需要获取 Xray ..."
    mkdir -p /opt/bin
    ok=0

    if [ "$GH_REPO" != "__REPO__" ]; then
        if dl "xray.gz" /tmp/xray.bin; then
            got=$(md5sum /tmp/xray.bin 2>/dev/null | awk '{print $1}')
            if [ "$got" = "$XRAY_MD5" ]; then
                cp -f /tmp/xray.bin "$XRAY_BIN"
                chmod +x "$XRAY_BIN"
                log "  Xray 下载成功, MD5 校验通过"
                ok=1
            else
                log "  MD5 不匹配: ${got:-空}"
            fi
        fi
    fi

    # 局域网兜底 (如果 GitHub 全挂)
    if [ "$ok" != "1" ]; then
        for url in "http://192.168.2.202:8899/xray.gz"; do
            log "尝试局域网: $url"
            wget -q -O /tmp/xray.dl --timeout=120 "$url" 2>/dev/null
            if [ -s /tmp/xray.dl ]; then
                gunzip -c /tmp/xray.dl > /tmp/xray.bin 2>/dev/null
                got=$(md5sum /tmp/xray.bin 2>/dev/null | awk '{print $1}')
                if [ "$got" = "$XRAY_MD5" ]; then
                    cp -f /tmp/xray.bin "$XRAY_BIN"
                    chmod +x "$XRAY_BIN"
                    log "  局域网下载成功"
                    ok=1
                    break
                fi
            fi
        done
    fi

    rm -f /tmp/xray.dl /tmp/xray.bin

    if [ "$ok" != "1" ]; then
        log "错误: 无法获取 Xray"
        log "保底: 不启动代理, 正常上网不受影响"
        rollback
        exit 0
    fi
fi

# ============================================================
# 6. 配置文件
# ============================================================
if [ ! -f "$XRAY_DIR/config.json" ]; then
    log "错误: 配置不存在: $XRAY_DIR/config.json"
    rollback
    exit 0
fi
cp -f "$XRAY_DIR/config.json" /tmp/xray_cfg.json

# ============================================================
# 7. 启动 Xray
# ============================================================
killall xray 2>/dev/null
sleep 2
ulimit -n 4096 2>/dev/null
"$XRAY_BIN" -c /tmp/xray_cfg.json > /tmp/xray_run.log 2>&1 &
sleep 6

if ! pgrep xray >/dev/null 2>&1; then
    log "错误: Xray 启动失败"
    tail -5 /tmp/xray_run.log 2>/dev/null | while read l; do log "  $l"; done
    rollback
    exit 0
fi
log "Xray 启动成功 (PID=$(pgrep xray))"

# ============================================================
# 8. 策略路由
# ============================================================
ip rule add fwmark 1 table 100 2>/dev/null
ip route add local 0.0.0.0/0 dev lo table 100 2>/dev/null

# ============================================================
# 9. 中国 IP 集合
# ============================================================
if [ -f "$XRAY_DIR/china_ip.txt" ]; then
    ipset destroy china 2>/dev/null
    ipset create china hash:net maxelem 100000 2>/dev/null
    while IFS= read -r ip; do
        [ -z "$ip" ] && continue
        ipset add china "$ip" 2>/dev/null
    done < "$XRAY_DIR/china_ip.txt"
    log "中国IP集合已加载 ($(ipset list china 2>/dev/null | grep -c '^[0-9]') 条)"
else
    log "警告: 无中国IP列表"
fi

# ============================================================
# 10. 透明代理规则 (只拦国外!)
# ============================================================
while iptables -t nat -D PREROUTING -p tcp -s "$LAN_NET" -j CLASH 2>/dev/null; do :; done
iptables -t nat -F CLASH 2>/dev/null
iptables -t nat -X CLASH 2>/dev/null

iptables -t mangle -D PREROUTING -p tcp -s "$LAN_NET" -j XRAY_TPROXY 2>/dev/null
iptables -t mangle -F XRAY_TPROXY 2>/dev/null
iptables -t mangle -X XRAY_TPROXY 2>/dev/null
iptables -t mangle -N XRAY_TPROXY

iptables -t mangle -A XRAY_TPROXY -d 198.18.0.0/16 -j RETURN

for net in 0.0.0.0/8 10.0.0.0/8 127.0.0.0/8 169.254.0.0/16 172.16.0.0/12 \
           192.168.0.0/16 224.0.0.0/4 240.0.0.0/4 100.64.0.0/10; do
    iptables -t mangle -A XRAY_TPROXY -d $net -j RETURN
done

# 中国 IP 直连 (核心保底)
iptables -t mangle -A XRAY_TPROXY -m set --match-set china dst -j RETURN

# 其余走代理
iptables -t mangle -A XRAY_TPROXY -p tcp -j TPROXY --on-port 10810 --tproxy-mark 1

iptables -t mangle -A PREROUTING -p tcp -s "$LAN_NET" ! -i lo -j XRAY_TPROXY

log "透明代理规则已应用 (LAN: $LAN_NET)"

# ============================================================
# 11. 看门狗
# ============================================================
if [ -f "$XRAY_DIR/watchdog.sh" ]; then
    killall watchdog.sh 2>/dev/null
    sleep 1
    "$XRAY_DIR/watchdog.sh" > /dev/null 2>&1 &
    log "看门狗已启动"
fi

log "===== 启动完成 ====="
exit 0
